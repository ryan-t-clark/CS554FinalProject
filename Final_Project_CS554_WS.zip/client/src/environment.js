// let baseUrl = "http://52.91.163.243/api";
let baseUrl = "http://localhost:3008/api";

module.exports = {
    baseUrl
}