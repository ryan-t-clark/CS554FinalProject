## Available Scripts

In the project directory, you can run:

### `npm start`

Launches the server.\
Server runs on http://localhost:3008.

